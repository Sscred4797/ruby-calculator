# Проста калькулятор-програма на Ruby

puts "Введіть перше число:"
a = gets.to_f

puts "Введіть друге число:"
b = gets.to_f

puts "Оберіть дію (+, -, *, /):"
operation = gets.chomp

result = case operation
when "+"
  a + b
when "-"
  a - b
when "*"
  a * b
when "/"
  if b != 0
    a / b
  else
    "Помилка: ділення на нуль!"
  end
else
  "Невідома операція"
end

puts "Результат: #{result}"
